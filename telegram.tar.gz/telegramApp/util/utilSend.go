package util

import (
	"bytes"
	"fmt"
	jsoniter "github.com/json-iterator/go"
	"github.com/mijia/sweb/log"
	"io/ioutil"
	"net/http"
)

//新的json转换库，速度更快
var Jsoniteror = jsoniter.ConfigCompatibleWithStandardLibrary

type RetResult struct {
	Code    int    `json:"code"`
	Message string `json:"message"`
}

func HttpGet(url string) ([]byte, error) {
	resp, err := http.Get(url)
	if err != nil {
		return nil, err
	}
	return ioutil.ReadAll(resp.Body)
}

func HttpPost(url string, data interface{}) ([]byte, error) {
	contentType := "application/json"
	//var res *http.Response
	buf, err := json.Marshal(data)
	if err != nil {
		log.Errorf("Marshal failed,err:%+v,data:%+v", err, data)
		return nil, err
	}

	body := bytes.NewBuffer(buf)
	res, err := http.Post(url, contentType, body)
	if err != nil {
		log.Errorf("post failed,err:%+v,data:%+v", err, data)
		return nil, err
	}

	resBody, err := ioutil.ReadAll(res.Body)
	defer res.Body.Close()
	if err != nil {
		log.Errorf("Post ReadAll failed,err:%+v,url:%+v,data:%+v", err, url, data)
		return nil, err
	}
	return resBody, nil
}

func PostXml(url string, data []byte) ([]byte, error) {
	req, err := http.NewRequest("POST", url, bytes.NewReader(data))
	if err != nil {
		fmt.Println("New Http Request发生错误，原因:", err)
		return nil, err
	}
	req.Header.Set("Accept", "application/xml")
	//这里的http header的设置是必须设置的.
	req.Header.Set("Content-Type", "application/xml;charset=utf-8")
	log.Info("url: %+v, buf: %v", url, string(data))
	c := http.Client{}
	resp, err := c.Do(req)
	defer resp.Body.Close()
	if err != nil {
		log.Errorf("post failed,err:%+v,data:%+v", err, string(data))
		return nil, err
	}
	resBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Errorf("Post ReadAll failed,err:%+v,url:%+v,data:%+v", err, url, string(data))
		return nil, err
	}
	return resBody, nil
}
