package util

import (
	"github.com/spf13/viper"
	fl "github.com/zhouruisong/fileLogger"
)

type LogManager struct {
	Lg *fl.FileLogger
}

var rancherLog *LogManager

func Init() {
	rancherLog = NewLogger(viper.GetString("outputFile"), "telegram")
}

func NewLogger(path string, logName string) (l *LogManager) {
	l = &LogManager{
		Lg: fl.NewDailyLogger(path, logName, "", 30, 5000),
	}

	l.Lg.SetLogLevel(fl.INFO)
	return l
}

func Logr() *LogManager {
	return rancherLog
}

func (l *LogManager) SetLevel(level int) {
	lv := fl.LEVEL(level)
	l.Lg.SetLogLevel(lv)
}

func (l *LogManager) ParamInfo(prefix string, p interface{}) {
	l.Lg.I(4, "%v%#v", prefix, p)
}

func (l *LogManager) ParamWarn(prefix string, p interface{}) {
	l.Lg.W(4, "%v%#v", prefix, p)
}

func (l *LogManager) ParamError(prefix string, p interface{}) {
	l.Lg.E(4, "%v%#v", prefix, p)
}

func (l *LogManager) Trace(format string, v ...interface{}) {
	l.Lg.T(4, format, v...)
}

func (l *LogManager) Info(format string, v ...interface{}) {
	l.Lg.I(4, format, v...)
}

func (l *LogManager) Warn(format string, v ...interface{}) {
	l.Lg.W(4, format, v...)
}

func (l *LogManager) Error(format string, v ...interface{}) {
	l.Lg.E(4, format, v...)
}
