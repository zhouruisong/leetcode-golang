package config

import (
	"fmt"
	"github.com/fsnotify/fsnotify"
	"github.com/spf13/viper"
)

func Init(cfgPath string) {
	//v := viper.New()
	viper.SetConfigName("config") // name of config file (without extension)
	viper.SetConfigType("toml")   // REQUIRED if the config file does not have the extension in the name
	viper.AddConfigPath(cfgPath)  // path to look for the config file in

	err := viper.ReadInConfig() // Find and read the config file
	if err != nil {             // Handle errors reading the config file
		panic(fmt.Errorf("Fatal error config file: %s \n", err))
	}

	viper.WatchConfig()
	viper.OnConfigChange(func(e fsnotify.Event) {
		fmt.Println("Config file changed:", e.Name)
		//c := Config{}
		//err = viper.Unmarshal(&c)
		//if err != nil { // Handle errors reading the config file
		//	panic(fmt.Errorf("Fatal error config file: %s \n", err))
		//}
		//fmt.Printf("%+v\n", c)
	})
}

// Config 配置参数
type Config struct {
	Token string
}
