package main

import (
	"bytes"
	"flag"
	"fmt"
	"io/ioutil"
	"mime/multipart"
	"net/http"
	"telegramApp/src/telegramApp/config"
	"telegramApp/src/telegramApp/util"
)

//const Token  = "1752758257:AAGb7ygqL-Ly7N3Zm_XvMUremu75QJIA9IA"

var configPath = flag.String("config", "/home/zrs/code/project/src/telegramApp/src/telegramApp/", "config path")

func main() {
	flag.Parse()
	// 从配置文件读取配置
	config.Init(*configPath)
	util.Init()

	//"https://api.telegram.org/bot1752758257:AAGb7ygqL-Ly7N3Zm_XvMUremu75QJIA9IA/sendMessage?chat_id=-558442029&text=my sample text"

	url := "https://api.telegram.org/bot1752758257:AAGb7ygqL-Ly7N3Zm_XvMUremu75QJIA9IA/sendMessage?chat_id=-558442029&text=my%20sample%20text"
	method := "POST"

	payload := &bytes.Buffer{}
	writer := multipart.NewWriter(payload)
	err := writer.Close()
	if err != nil {
		fmt.Println(err)
		return
	}

	client := &http.Client{}
	req, err := http.NewRequest(method, url, payload)

	if err != nil {
		fmt.Println(err)
		return
	}
	req.Header.Set("Content-Type", writer.FormDataContentType())
	res, err := client.Do(req)
	if err != nil {
		fmt.Println(err)
		return
	}
	defer res.Body.Close()

	body, err := ioutil.ReadAll(res.Body)
	if err != nil {
		fmt.Println(err)
		return
	}
	fmt.Println(string(body))
	//st := tb.Settings{
	//	// You can also set custom API URL.
	//	// If field is empty it equals to "https://api.telegram.org".
	//	URL: "https://api.telegram.org",
	//	Token:  viper.GetString("Token"),
	//	Poller: &tb.LongPoller{Timeout: 10 * time.Second},
	//}
	//
	//b, err := tb.NewBot(st)
	//
	//if err != nil {
	//	log.Fatal(err)
	//	return
	//}
	//
	//b.Handle("/hello", func(m *tb.Message) {
	//	b.Send(m.Sender, "Hello World!")
	//})
	//
	//b.Start()
}
